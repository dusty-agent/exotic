EXOTIC ORDINARY®
Mood Archive

Thank you for supporting Mood Archive.

Aqua Veil captures the memory of a rainy spring day—
blue light, drifting petals, and dreams floating beneath the water.

Included in this download:

• High-resolution desktop wallpapers
• High-resolution mobile wallpapers
• LICENSE.txt

Recommended use:

• Desktop wallpaper
• Mobile wallpaper
• Personal moodboards
• Personal inspiration

Please read LICENSE.txt before using these files.

Every purchase directly supports the creation of future visual archives, ambient music, and new digital experiences from EXOTIC ORDINARY®.

Thank you for being part of this journey.

—

EXOTIC ORDINARY®

https://exoticordinary.com
hello@exoticordinary.com

© EXOTIC ORDINARY®. All Rights Reserved.